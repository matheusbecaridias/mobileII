import React, { useState } from 'react';
import { StyleSheet, View, FlatList } from 'react-native';
import { TextInput, Button, Card, Text } from 'react-native-paper';

export default function App() {
  const [task, setTask] = useState('');
  const [tasks, setTasks] = useState([]);

  const addTask = () => {
    if (task.trim() !== '') {
      setTasks([...tasks, task]);
      setTask('');
    }
  };

  const clearTasks = () => {
    setTasks([]);
  };

  return (
    <View style={styles.container}>
      <Card style={styles.card}>
        <Card.Content>
          <Text variant="titleLarge" style={styles.title}>To-do List</Text>
          
          <TextInput
            label='Nova Tarefa'
            mode='outlined'
            value={task}
            onChangeText={setTask}
            style={styles.input}
          />

          <Button mode='contained' onPress={addTask} style={styles.button}>
            Adicionar
          </Button>
          
          <Button mode='outlined' onPress={clearTasks} style={styles.button}>
            Limpar tudo
          </Button>
        </Card.Content>
      </Card>

      <FlatList
        data={tasks}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <Card style={styles.taskCard}>
            <Card.Content>
              <Text>{item}</Text>
            </Card.Content>
          </Card>
        )}
        style={styles.list}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    backgroundColor: '#f5f5f5',
  },
  card: {
    marginBottom: 20,
    padding: 10,
  },
  title: {
    marginBottom: 15,
    textAlign: 'center',
    fontWeight: 'bold',
  },
  input: {
    marginBottom: 15,
  },
  button: {
    marginTop: 10,
  },
  list: {
    marginTop: 10,
  },
  taskCard: {
    marginTop: 8,
  },
});