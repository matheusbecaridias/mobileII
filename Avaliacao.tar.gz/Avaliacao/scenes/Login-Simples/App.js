
import React, { useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { Card, TextInput, Button, Text } from 'react-native-paper';

export default function App() {
  const [name, setName] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [submittedName, setSubmittedName] = useState('');

  const handleLogin = () => {
    if (name.trim() !== '') {
      setSubmittedName(name);
      setIsLoggedIn(true);
    }
  };

  const handleLogout = () => {
    setName('');
    setIsLoggedIn(false);
  };

  return (
    <View style={styles.container}>
      <Card style={styles.card}>
        <Card.Content>
          {!isLoggedIn ? (
            <>
              <Text variant="titleLarge" style={styles.title}>
                Welcome
              </Text>
              <Text style={styles.subtitle}>Please enter your name to continue</Text>

              <TextInput
                label="Name"
                mode="outlined"
                value={name}
                onChangeText={setName}
                style={styles.input}
              />

              <Button mode="contained" onPress={handleLogin} style={styles.button}>
                Login
              </Button>
            </>
          ) : (
            <>
              <Text variant="titleLarge" style={styles.title}>
                Hello, {submittedName}! 👋
              </Text>
              <Text style={styles.subtitle}>You have successfully logged in.</Text>

              <Button mode="outlined" onPress={handleLogout} style={styles.button}>
                Log Out
              </Button>
            </>
          )}
        </Card.Content>
      </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 16,
  },
  card: {
    padding: 8,
    borderRadius: 12,
  },
  title: {
    textAlign: 'center',
    fontWeight: 'bold',
    marginBottom: 8,
  },
  subtitle: {
    textAlign: 'center',
    color: '#666',
    marginBottom: 24,
  },
  input: {
    marginBottom: 16,
  },
  button: {
    marginTop: 8,
    paddingVertical: 4,
  },
});
