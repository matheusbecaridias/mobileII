import React from 'react';
import { StyleSheet, Text, View, StatusBar } from 'react-native';

export default function app () {
  return (
    <View style={estilos.container}>

    <StatusBar barStyle="dark-content" background="#f0f0f0"/>

    <Text style={estilos.titulo}> Ola, Alunos. Welcome!</Text> 
    <Text style={estilos.textoComum}> Este texto usa cores definidas no Estilo </Text>
    </View>
  );
}

const estilos = StyleSheet.create({
 container: {
   flex: 1,
   background: '#f0f0f0',
   alignItems: 'center',
   justifyContent: 'center', 
   padding: 20, 
 },

titulo: {
  fontSize: 16,
  color: '#374151',
  textAlign:'center',
},

textoComum: {
  fontSize: 16,
  color: '#374151',
  textAlign:'center',
}


}); 