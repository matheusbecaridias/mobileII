import React from 'react';
import { StyleSheet, View, StatusBar } from 'react-native';
import Cesta from './src/Telas/cesta';
import Itens from './src/Telas/items';
import { Dimensions } from 'react-native';

export default function App() {
  return (
    <View style={estilos.container}>
      <Cesta />
      <Itens/> 
      <StatusBar style="auto" />
    </View>
  );
}

const estilos = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'flex-start', // deixa a imagem no topo
  },
});