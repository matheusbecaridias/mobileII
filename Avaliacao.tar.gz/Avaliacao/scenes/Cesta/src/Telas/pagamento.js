import React from 'react';
import { StyleSheet, Text, View, TouchableOpacity, ScrollView } from 'react-native';

export default function Pagamento({ itensSacola = [], onVoltar }) {
  // Exemplo simples de cálculo de total baseando-se nos itens passados
  const totalGeral = itensSacola.reduce((soma, item) => {
    // Remove "R$", troca vírgula por ponto para somar corretamente
    const valorNumerico = parseFloat(item.preco.replace('R$', '').replace(',', '.').trim()) || 0;
    return soma + valorNumerico;
  }, 0);

  return (
    <ScrollView style={estilos.container} showsVerticalScrollIndicator={false}>
      <Text style={estilos.titulo}>Resumo do Pedido</Text>

      {/* Lista de itens na sacola */}
      <View style={estilos.secao}>
        <Text style={estilos.subtitulo}>Itens na Sacola</Text>
        {itensSacola.length === 0 ? (
          <Text style={estilos.vazio}>Sua sacola está vazia.</Text>
        ) : (
          itensSacola.map((item, index) => (
            <View key={index} style={estilos.itemLinha}>
              <Text style={estilos.itemNome}>{item.nome}</Text>
              <Text style={estilos.itemPreco}>{item.preco}</Text>
            </View>
          ))
        )}
      </View>

      {/* Total */}
      <View style={estilos.totalContainer}>
        <Text style={estilos.totalTexto}>Total a Pagar:</Text>
        <Text style={estilos.totalValor}>R$ {totalGeral.toFixed(2).replace('.', ',')}</Text>
      </View>

      {/* Opções de Pagamento */}
      <View style={estilos.secao}>
        <Text style={estilos.subtitulo}>Forma de Pagamento</Text>
        <TouchableOpacity style={estilos.opcaoPagamento}>
          <Text style={estilos.textoOpcao}>💳 Cartão de Crédito / Débito</Text>
        </TouchableOpacity>
        <TouchableOpacity style={estilos.opcaoPagamento}>
          <Text style={estilos.textoOpcao}>pix Pix</Text>
        </TouchableOpacity>
        <TouchableOpacity style={estilos.opcaoPagamento}>
          <Text style={estilos.textoOpcao}>💵 Dinheiro na Entrega</Text>
        </TouchableOpacity>
      </View>

      {/* Botões de Ação */}
      <TouchableOpacity 
        style={estilos.botaoFinalizar} 
        onPress={() => alert('Pedido finalizado com sucesso!')}
      >
        <Text style={estilos.textoBotaoFinalizar}>Confirmar Pedido</Text>
      </TouchableOpacity>

      {onVoltar && (
        <TouchableOpacity style={estilos.botaoVoltar} onPress={onVoltar}>
          <Text style={estilos.textoBotaoVoltar}>Voltar para a Feira</Text>
        </TouchableOpacity>
      )}
    </ScrollView>
  );
}

const estilos = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16,
    backgroundColor: '#fff',
    paddingTop: 16,
  },
  titulo: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#464646',
    marginBottom: 16,
    textAlign: 'center',
  },
  secao: {
    marginBottom: 20,
    backgroundColor: '#FAFAFA',
    borderRadius: 8,
    padding: 12,
    borderWidth: 1,
    borderColor: '#F0F0F0',
  },
  subtitulo: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#464646',
    marginBottom: 8,
  },
  vazio: {
    color: '#A3A3A3',
    fontStyle: 'italic',
  },
  itemLinha: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 6,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  itemNome: {
    color: '#464646',
    fontSize: 14,
  },
  itemPreco: {
    color: '#2A9F85',
    fontWeight: 'bold',
    fontSize: 14,
  },
  totalContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    backgroundColor: '#E8F5E9',
    borderRadius: 8,
    marginBottom: 20,
  },
  totalTexto: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2E7D32',
  },
  totalValor: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#2E7D32',
  },
  opcaoPagamento: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: '#DDDDDD',
    marginBottom: 8,
  },
  textoOpcao: {
    fontSize: 14,
    color: '#464646',
    fontWeight: 'bold',
  },
  botaoFinalizar: {
    backgroundColor: '#2A9F85',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 10,
    elevation: 2,
  },
  textoBotaoFinalizar: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  botaoVoltar: {
    paddingVertical: 12,
    alignItems: 'center',
    marginBottom: 30,
  },
  textoBotaoVoltar: {
    color: '#A3A3A3',
    fontSize: 14,
    fontWeight: 'bold',
  },
});