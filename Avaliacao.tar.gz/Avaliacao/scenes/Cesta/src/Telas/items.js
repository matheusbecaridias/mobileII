import React, { useState } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, ScrollView, Image } from 'react-native';
import Pagamento from './pagamento'; // Importe a tela que criamos acima (ajuste o caminho se necessário)

export default function Itens() {
  const [sacola, setSacola] = useState([]); // Guarda os objetos dos produtos adicionados
  const [exibindoPagamento, setExibindoPagamento] = useState(false); // Controla qual tela aparece

  const listaProdutos = [
    { id: '1', nome: 'Abacate', preco: 'R$ 6,00', imagem: require('../../assets/abacate.jpg') },
    { id: '2', nome: 'Banana', preco: 'R$ 4,00', imagem: require('../../assets/banana.jpg') },
    { id: '3', nome: 'frutasfeira', preco: 'R$ 8,00', imagem: require('../../assets/frutasfeira.jpg') }
  ];

  const adicionarNaSacola = (produto) => {
    setSacola([...sacola, produto]);
  };

  // Se o usuário clicou para ir ao pagamento, exibe a tela de pagamento
  if (exibindoPagamento) {
    return <Pagamento itensSacola={sacola} onVoltar={() => setExibindoPagamento(false)} />;
  }

  return (
    <ScrollView style={estilos.container} showsVerticalScrollIndicator={false}>
      {/* Cabeçalho da Seção com clique na sacola */}
      <View style={estilos.topoLista}>
        <Text style={estilos.titulo}>Feira de Frutas</Text>
        
        <TouchableOpacity onPress={() => setExibindoPagamento(true)}>
          <Text style={estilos.sacola}>🛒 Sacola: {sacola.length}</Text>
        </TouchableOpacity>
      </View>
      
      {listaProdutos.map((produto) => (
        <View key={produto.id} style={estilos.itemContainer}>
          <Image source={produto.imagem} style={estilos.fotoFruta} />
          
          <View style={estilos.infoContainer}>
            <Text style={estilos.nomeFruta} numberOfLines={1}>{produto.nome}</Text>
            <Text style={estilos.precoFruta}>{produto.preco}</Text>
          </View>

          <TouchableOpacity 
            style={estilos.botaoComprar} 
            onPress={() => adicionarNaSacola(produto)}
          >
            <Text style={estilos.textoBotao}>Comprar</Text>
          </TouchableOpacity>
        </View>
      ))}
    </ScrollView>
  );
}

// (Mantenha os estilos que você já tinha no items.js abaixo...)
const estilos = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 16, backgroundColor: '#fff' },
  topoLista: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 16, paddingBottom: 8, borderBottomWidth: 2, borderBottomColor: '#ECECEC' },
  titulo: { fontSize: 20, fontWeight: 'bold', color: '#464646' },
  sacola: { fontSize: 14, color: '#2A9F85', fontWeight: 'bold' },
  itemContainer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#FAFAFA', borderRadius: 8, paddingVertical: 14, paddingHorizontal: 16, marginBottom: 12, borderWidth: 1, borderColor: '#F0F0F0', width: '100%' },
  fotoFruta: { width: 55, height: 55, borderRadius: 27.5 },
  infoContainer: { flex: 1, marginHorizontal: 14 },
  nomeFruta: { fontSize: 16, fontWeight: 'bold', color: '#464646' },
  precoFruta: { fontSize: 14, color: '#2A9F85', marginTop: 4, fontWeight: 'bold' },
  botaoComprar: { backgroundColor: '#2A9F85', paddingVertical: 8, paddingHorizontal: 14, borderRadius: 6, elevation: 2, alignItems: 'center' },
  textoBotao: { color: '#fff', fontSize: 14, fontWeight: 'bold' }
});