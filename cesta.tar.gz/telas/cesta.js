import React from 'react';
import { StyleSheet, Image, Text, View, Dimensions } from 'react-native';

import bicolor from '../../assets/bicolor.jpg';
import logo from '../../assets/logo.jpg';

const { width, height } = Dimensions.get('window');

export default function Cesta() {
  return (
    <View style={estilos.topo}>
      <Image
        source={bicolor}
        style={estilos.imagemBicolor}
        resizeMode="cover"
      />

      {/* Texto de topo que fica sobreposto à imagem */}
      <Text style={estilos.texto}>Detalhe da Cesta</Text>

      <View style={estilos.cesta}>
        <Text style={estilos.titulo}>Cesta de Verduras</Text>

        {/* View com flex row para alinhar a logo ao lado do texto */}
        <View style={estilos.fazenda}>
          <Image source={logo} style={estilos.imagemFazenda} />
          <Text style={estilos.nomeFazenda}>Jenny Jack Farm</Text>
        </View>

        <Text style={estilos.frase}>
          Uma cesta com produtos selecionados cuidadosamente da fazenda direto para sua
          cozinha
        </Text>

        <Text style={estilos.preco}>R$ 40,00</Text>
      </View>
    </View>
  );
}

const estilos = StyleSheet.create({
  topo: {
    width: '100%',
  },

  imagemBicolor: {
    width: width,
    height: height * 0.3,
  },

  texto: {
    width: '100%',
    position: 'absolute',
    textAlign: 'center',
    fontSize: 16,
    lineHeight: 26,
    color: '#fff',
    fontWeight: 'bold',
    padding: 16,
  },

  cesta: {
    paddingVertical: 8,
    paddingHorizontal: 16,
  },

  titulo: {
    fontSize: 26,
    lineHeight: 42,
    color: '#464646',
    fontWeight: 'bold',
  },

  fazenda: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
  },

  imagemFazenda: {
    width: 32,
    height: 32,
  },

  nomeFazenda: {
    color: '#464646',
    fontSize: 16,
    lineHeight: 26,
    marginLeft: 12,
  },

  frase: {
    color: '#A3A3A3',
    fontSize: 16,
    lineHeight: 26,
  },

  preco: {
    color: '#2A9F85',
    fontWeight: 'bold',
    fontSize: 25,
    lineHeight: 42,
    marginTop: 8,
  },
});
