import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, View } from 'react-native';
import cesta from './src/telas/cesta';
import itens from './src/telas/items';
import {Dimensions} from 'react-native';

export default function App() {
  return (
    <View style={estilos.container}>
      <cesta />
      <StatusBar style="auto" />
    </View>
  );
}

const estilos = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'flex-start', // deixa a imagem no topo
  },
});
